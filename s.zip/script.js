document.addEventListener('DOMContentLoaded', function() {
    const apiKey = '(https://console.cloud.google.com/marketplace/product/google/youtube.googleapis.com?project=supple-flux-425212-m5) Get yourself the youtube api and then the videos will pop up.';
    const channelId = 'ChannelID';
    const videoGrid = document.getElementById('video-grid');
    const subscriberCountElement = document.getElementById('subscriber-count');
    const themeToggle = document.getElementById('theme-toggle');
    const contactForm = document.getElementById('contact-form');
    const loadingScreen = document.getElementById('loading-screen');
    const loadingText = document.getElementById('loading-text');

    // Fetch latest videos from the YouTube channel
    fetch(`https://www.googleapis.com/youtube/v3/search?key=${apiKey}&channelId=${channelId}&part=snippet,id&order=date&maxResults=10`)
        .then(response => response.json())
        .then(data => {
            data.items.forEach(item => {
                if (item.id.videoId) {
                    const videoId = item.id.videoId;
                    const title = item.snippet.title;
                    const thumbnail = item.snippet.thumbnails.high.url;
                    const videoCard = `
                        <div class="video-card">
                            <img src="${thumbnail}" alt="${title}">
                            <h3>${title}</h3>
                            <button onclick="window.open('https://www.youtube.com/watch?v=${videoId}', '_blank')">Watch Now</button>
                        </div>
                    `;
                    videoGrid.innerHTML += videoCard;
                }
            });
        })
        .catch(error => console.error('Error fetching videos:', error));

    // Fetch subscriber count from the YouTube channel
    fetch(`https://www.googleapis.com/youtube/v3/channels?part=statistics&id=${channelId}&key=${apiKey}`)
        .then(response => response.json())
        .then(data => {
            const subscriberCount = data.items[0].statistics.subscriberCount;
            subscriberCountElement.textContent = `Subscribers: ${subscriberCount}`;
        })
        .catch(error => console.error('Error fetching subscriber count:', error));

    // Smooth scroll to sections
    document.querySelectorAll('nav ul li a').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            document.querySelector(this.getAttribute('href')).scrollIntoView({
                behavior: 'smooth'
            });
        });
    });

    // Handle form submission
    contactForm.addEventListener('submit', async function(e) {
        e.preventDefault();

        const firstName = document.getElementById('first-name').value.trim();
        const lastName = document.getElementById('last-name').value.trim();
        const email = document.getElementById('email').value.trim();
        const notes = document.getElementById('notes').value.trim();
        const country = document.getElementById('country').value.trim();
        const jobTitle = document.getElementById('job-title').value.trim();

        // Email validation regex
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        // Simple troll-checking mechanism
        const bannedWords = ['badword1', 'badword2']; // Add more words as needed
        const containsTrollContent = bannedWords.some(word => 
            [firstName, lastName, email, notes, country, jobTitle].some(field => field.toLowerCase().includes(word))
        );

        // Validate email format
        if (!emailRegex.test(email)) {
            alert('Please enter a valid email address.');
            return;
        }

        if (containsTrollContent) {
            alert('Your submission contains inappropriate content. Please revise and try again.');
            return;
        }

        const message = {
            username: 'Contact Form',
            embeds: [{
                title: 'New Contact Form Submission',
                fields: [
                    { name: 'First Name', value: firstName || 'N/A', inline: true },
                    { name: 'Last Name', value: lastName || 'N/A', inline: true },
                    { name: 'Email', value: email || 'N/A', inline: true },
                    { name: 'Notes', value: notes || 'N/A', inline: false },
                    { name: 'Country', value: country || 'N/A', inline: true },
                    { name: 'Job Title', value: jobTitle || 'N/A', inline: true }
                ],
                timestamp: new Date().toISOString()
            }]
        };

        // Send data to Discord webhook
        fetch('DiscordWebhookHere', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(message)
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            alert('Your message has been sent successfully!');
            contactForm.reset(); // Optional: reset the form fields after submission
        })
        .catch(error => {
            console.error('Error sending form data:', error);
            alert('There was a problem sending your message. Please try again later.');
        });
    });

    // Toggle dark mode
    themeToggle.addEventListener('click', () => {
        document.body.classList.toggle('dark-mode');
        localStorage.setItem('dark-mode', document.body.classList.contains('dark-mode'));
    });

    // Load dark mode preference
    if (localStorage.getItem('dark-mode') === 'true') {
        document.body.classList.add('dark-mode');
    }

    // Show loading screen
    const loadingAnimation = ['Loading.', 'Loading..', 'Loading...'];
    let loadingIndex = 0;

    const loadingInterval = setInterval(() => {
        loadingText.textContent = loadingAnimation[loadingIndex];
        loadingIndex = (loadingIndex + 1) % loadingAnimation.length;
    }, 500);

    window.addEventListener('load', () => {
        clearInterval(loadingInterval);
        loadingScreen.classList.add('hidden');
    });
});
